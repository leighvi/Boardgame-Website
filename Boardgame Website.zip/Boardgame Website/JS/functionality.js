function review(){
	//save data from form
	var name = $("input[name='name-text']").val();
	var revText= $("#txt-area").val();

	//check for blank data
	if(name==="" || revText===""){
		alert("Please fill out both fields.");
	}

	else{
		//get time stamp
		var dt = new Date();

		//remove form from page
		$("#review-form").remove();

		//add table containing review in place of form
		$("#review-contain").append('<div class="rForm"><table class="rev-table"><tr><th id="rev-name"><th></tr><tr><td id="rev-text"></td></tr></table></div>');
		$("#rev-name").html(name + "<br>" + dt);
		$("#rev-text").html(revText);
	}
}